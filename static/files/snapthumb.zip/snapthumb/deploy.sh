#!/usr/bin/env bash
# Deploy toàn bộ SnapThumb lên AWS bằng một lệnh.
# Chạy trong AWS CloudShell (khuyên dùng) hoặc máy có AWS CLI v2, Python 3 và pip.
#   bash deploy.sh                     # deploy hoặc cập nhật
#   STACK_NAME=demo bash deploy.sh     # tên stack khác (chỉ chữ thường, số, dấu -)
#   ALARM_EMAIL=ban@example.com bash deploy.sh   # nhận email khi CloudWatch alarm báo động
set -euo pipefail

REGION="${AWS_REGION:-ap-southeast-1}"
STACK="${STACK_NAME:-snapthumb}"
DIR="$(cd "$(dirname "$0")" && pwd)"
BUILD="$(mktemp -d)"
export AWS_REGION="$REGION" AWS_DEFAULT_REGION="$REGION"
trap 'rm -rf "$BUILD"' EXIT

step() { printf '\n\033[1;36m==> %s\033[0m\n' "$1"; }
out() {
  aws cloudformation describe-stacks --stack-name "$STACK" \
    --query "Stacks[0].Outputs[?OutputKey=='$1'].OutputValue" --output text
}
zipdir() {  # zipdir <thư mục> <file zip>: nén nội dung thư mục, đường dẫn tính từ gốc thư mục
  python3 - "$1" "$2" <<'PY'
import os, sys, zipfile
src, dst = sys.argv[1], sys.argv[2]
with zipfile.ZipFile(dst, "w", zipfile.ZIP_DEFLATED) as z:
    for root, _, files in os.walk(src):
        for f in files:
            p = os.path.join(root, f)
            z.write(p, os.path.relpath(p, src))
PY
}

if [[ ! "$STACK" =~ ^[a-z0-9][a-z0-9-]{0,20}$ ]]; then
  echo "STACK_NAME phải là chữ thường, số hoặc dấu '-', tối đa 21 ký tự (nó là một phần tên bucket S3)." >&2
  exit 1
fi

step "1/4 Tạo hoặc cập nhật hạ tầng (CloudFormation stack: $STACK, region: $REGION)"
PARAMS=()
if [ -n "${ALARM_EMAIL:-}" ]; then PARAMS=(--parameter-overrides "AlarmEmail=$ALARM_EMAIL"); fi
aws cloudformation deploy \
  --template-file "$DIR/infra/template.yaml" \
  --stack-name "$STACK" \
  --capabilities CAPABILITY_IAM \
  --no-fail-on-empty-changeset \
  "${PARAMS[@]}"

API_FN="$(out ApiFunctionName)"
THUMB_FN="$(out ThumbnailFunctionName)"
WEB_BUCKET="$(out WebBucketName)"
API_URL="$(out ApiUrl)"
WEBSITE_URL="$(out WebsiteUrl)"

step "2/4 Đóng gói hàm tạo thumbnail (kèm thư viện Pillow cho Lambda Python 3.12)"
mkdir -p "$BUILD/thumb" "$BUILD/api"
python3 -m pip install --quiet --disable-pip-version-check --target "$BUILD/thumb" \
  --platform manylinux_2_28_x86_64 --platform manylinux2014_x86_64 \
  --implementation cp --python-version 3.12 --only-binary=:all: \
  -r "$DIR/backend/requirements-thumbnail.txt"
cp "$DIR/backend/thumbnail.py" "$BUILD/thumb/"
cp "$DIR/backend/api.py" "$BUILD/api/"
zipdir "$BUILD/thumb" "$BUILD/thumb.zip"
zipdir "$BUILD/api" "$BUILD/api.zip"
echo "   thumbnail.zip: $(du -h "$BUILD/thumb.zip" | cut -f1)"

step "3/4 Cập nhật code Lambda"
for PAIR in "$THUMB_FN:$BUILD/thumb.zip" "$API_FN:$BUILD/api.zip"; do
  FN="${PAIR%%:*}"; ZIP="${PAIR#*:}"
  aws lambda update-function-code --function-name "$FN" --zip-file "fileb://$ZIP" \
    --query 'FunctionName' --output text
  aws lambda wait function-updated-v2 --function-name "$FN" 2>/dev/null \
    || aws lambda wait function-updated --function-name "$FN"
done

step "4/4 Đưa giao diện web lên s3://$WEB_BUCKET"
printf 'window.SNAPTHUMB_CONFIG = { apiUrl: "%s" };\n' "$API_URL" > "$DIR/web/config.js"
aws s3 sync "$DIR/web/" "s3://$WEB_BUCKET/" --delete --cache-control "no-cache"

printf '\n\033[1;32mXong!\033[0m\n'
echo "  Trang web : $WEBSITE_URL"
echo "  API       : $API_URL"
[ -n "${ALARM_EMAIL:-}" ] && echo "  Cảnh báo  : mở email $ALARM_EMAIL và bấm Confirm subscription"
echo
echo "Thử API:"
echo "  curl -s '$API_URL/images'"
