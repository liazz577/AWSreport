window.SNAPTHUMB_CONFIG = { apiUrl: "" };
