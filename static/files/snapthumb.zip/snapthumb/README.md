# SnapThumb

Dịch vụ tạo ảnh thu nhỏ (thumbnail) tự động, xây dựng theo kiến trúc **serverless, hướng sự kiện (event-driven)** trên AWS. Người dùng tải ảnh lên; ngay khi ảnh vào Amazon S3, AWS Lambda tự chạy để tạo ảnh thu nhỏ 320 px và ghi thông số vào Amazon DynamoDB. Trang web hiển thị ảnh thu nhỏ, kích thước, dung lượng giảm được và thời gian xử lý.

Không dùng Amazon Bedrock hay dịch vụ AI nào, nên chạy được ngay với tài khoản AWS mới.

```
Trình duyệt ──► S3 (website tĩnh)
    │
    ├─ 1. POST /uploads ──► API Gateway ──► Lambda API ──► DynamoDB (PENDING)
    │                                          └──► trả link upload có thời hạn (presigned POST)
    ├─ 2. Upload ảnh thẳng lên S3 (uploads/)
    │        └─ 3. Sự kiện ObjectCreated ──► Lambda Thumbnail (Pillow)
    │                                          ├──► S3 (thumbnails/)
    │                                          └──► DynamoDB (DONE + thông số)
    └─ 4. GET /images (hỏi lại mỗi 1,5 giây) ──► API Gateway ──► Lambda API ──► DynamoDB + link xem ảnh
```

## Tính năng

- Upload nhiều ảnh cùng lúc (JPEG, PNG, WebP, tối đa 10 MB/ảnh), kéo thả được.
- Ảnh đi **thẳng từ trình duyệt lên S3** bằng presigned POST: Lambda không phải nhận file lớn, S3 tự chặn file sai loại hoặc quá dung lượng.
- Thumbnail giữ đúng tỉ lệ, tự xoay theo EXIF (ảnh chụp điện thoại), ảnh PNG trong suốt được đặt lên nền trắng, ảnh nhỏ không bị phóng to.
- Theo dõi trạng thái: Đang xử lý → Xong / Lỗi, có thời gian xử lý thực tế.
- Bucket ảnh để **private**: chỉ xem được qua link có thời hạn 1 giờ.
- Giao diện song ngữ Việt/Anh, chạy trên điện thoại, có chế độ tối.
- **Chế độ demo**: mở `web/index.html` là chạy ngay (thu nhỏ ảnh trong trình duyệt), không cần AWS.
- Hạ tầng dưới dạng code (CloudFormation): một lệnh tạo, một lệnh xoá.

## Cấu trúc

```
snapthumb/
├── deploy.sh                       Deploy toàn bộ (hạ tầng, code, giao diện)
├── destroy.sh                      Xoá toàn bộ tài nguyên
├── infra/template.yaml             CloudFormation: S3 x2, DynamoDB, Lambda x2, API Gateway, IAM, CloudWatch Logs
├── backend/
│   ├── api.py                      Lambda API: POST /uploads, GET /images, DELETE /images/{id}
│   ├── thumbnail.py                Lambda tạo thumbnail (kích hoạt bởi S3)
│   ├── requirements-thumbnail.txt  Pillow (thư viện xử lý ảnh)
│   └── test_app.py                 Test toàn luồng trên AWS giả lập (moto)
└── web/
    ├── index.html                  Giao diện
    └── config.js                   URL của API (deploy.sh tự điền)
```

## 1. Xem thử ngay (không cần AWS)

Mở `web/index.html` bằng trình duyệt. Huy hiệu **Chế độ demo** cho biết ảnh đang được thu nhỏ ngay trong trình duyệt.

## 2. Deploy lên AWS

Dùng **AWS CloudShell** (terminal ngay trong AWS Console, có sẵn AWS CLI, Python và quyền của bạn):

1. Đăng nhập AWS Console bằng IAM user có quyền admin, chọn region **Asia Pacific (Singapore) ap-southeast-1**.
2. Bấm biểu tượng **CloudShell** (`>_` trên thanh trên cùng).
3. **Actions → Upload file** → chọn `snapthumb.zip`.
4. Chạy:

```bash
unzip -oq snapthumb.zip && cd snapthumb
export ALARM_EMAIL=ban@example.com   # tuỳ chọn: nhận email khi CloudWatch alarm báo động
bash deploy.sh
```

Script chạy khoảng 2–4 phút và in ra địa chỉ trang web:

```
Xong!
  Trang web : http://snapthumb-webbucket-xxxx.s3-website-ap-southeast-1.amazonaws.com
  API       : https://xxxx.execute-api.ap-southeast-1.amazonaws.com
```

Mở trang web: huy hiệu chuyển sang **Đã kết nối AWS**. Tải một ảnh lên, sau 1–3 giây ảnh thu nhỏ xuất hiện.

Sửa code xong, chạy lại `bash deploy.sh` để cập nhật.

Nếu đặt `ALARM_EMAIL`, AWS gửi thư xác nhận tới email đó: bấm **Confirm subscription** để nhận cảnh báo từ 3 CloudWatch alarm (hàm thumbnail lỗi, API trả 5xx, nhiều ảnh xử lý thất bại).

## 3. Chi phí

Với vài trăm ảnh mỗi tháng, chi phí gần như **0 USD**: Lambda, API Gateway, DynamoDB (on-demand) và S3 đều nằm trong Free Tier hoặc chỉ vài cent. Nên đặt AWS Budgets cảnh báo ở 5 USD.

## 4. Xoá toàn bộ

```bash
bash destroy.sh
```

## Kiểm thử

```bash
pip install "moto[s3,dynamodb]" Pillow
cd backend && python3 -m unittest -v
```

Test chạy toàn luồng trên AWS giả lập: tạo link upload → upload ảnh → Lambda tạo thumbnail → liệt kê → xoá, cùng các trường hợp ảnh hỏng, PNG trong suốt, ảnh dọc, ảnh nhỏ và dữ liệu đầu vào sai.

## Xử lý sự cố

| Hiện tượng | Cách xử lý |
| --- | --- |
| Stack lỗi ở `WebBucketPolicy` (Access Denied) | Tài khoản bật *Block Public Access* ở cấp account. Vào **S3 → Block Public Access settings for this account**, tắt 2 mục về *bucket policies*, rồi chạy lại `bash deploy.sh` |
| Lỗi tên bucket đã tồn tại | Tên bucket phải duy nhất toàn cầu. Đổi tên stack: `STACK_NAME=snapthumb2 bash deploy.sh` |
| Ảnh đứng mãi ở "Đang xử lý" | Xem log ở **CloudWatch → Log groups → /aws/lambda/snapthumb-ThumbnailFunction-…** |
| Ảnh báo "Lỗi" | File không phải ảnh hợp lệ; thông báo lỗi hiện ngay trên thẻ ảnh |
| Upload báo lỗi S3 403 | File lớn hơn 10 MB hoặc link upload đã hết hạn (5 phút); thử lại |
