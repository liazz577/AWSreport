"""Test toàn luồng trên AWS giả lập (moto), không cần tài khoản AWS.
Chạy: cd backend && python3 -m unittest -v
Cần: pip install "moto[s3,dynamodb]" Pillow
"""
import io
import json
import os
import unittest
from datetime import datetime, timezone

os.environ.update({
    "AWS_DEFAULT_REGION": "ap-southeast-1", "AWS_REGION": "ap-southeast-1",
    "AWS_ACCESS_KEY_ID": "test", "AWS_SECRET_ACCESS_KEY": "test",
    "TABLE_NAME": "snapthumb-images", "BUCKET_NAME": "snapthumb-images-test",
})

import boto3  # noqa: E402
from moto import mock_aws  # noqa: E402
from PIL import Image  # noqa: E402

import api  # noqa: E402
import thumbnail  # noqa: E402

REGION = "ap-southeast-1"
BUCKET = os.environ["BUCKET_NAME"]


def sample_image(fmt="JPEG", size=(1600, 1200), mode="RGB"):
    img = Image.new(mode, size, (30, 120, 200) if mode == "RGB" else (30, 120, 200, 128))
    buf = io.BytesIO()
    img.save(buf, fmt)
    return buf.getvalue()


def s3_event(key):
    return {"Records": [{
        "eventTime": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
        "s3": {"bucket": {"name": BUCKET}, "object": {"key": key}},
    }]}


@mock_aws
class FlowTest(unittest.TestCase):
    def setUp(self):
        api._s3 = api._table = thumbnail._s3 = thumbnail._table = None
        boto3.client("s3", region_name=REGION).create_bucket(
            Bucket=BUCKET, CreateBucketConfiguration={"LocationConstraint": REGION})
        boto3.client("dynamodb", region_name=REGION).create_table(
            TableName=os.environ["TABLE_NAME"], BillingMode="PAY_PER_REQUEST",
            AttributeDefinitions=[{"AttributeName": "id", "AttributeType": "S"}],
            KeySchema=[{"AttributeName": "id", "KeyType": "HASH"}])
        self.s3 = boto3.client("s3", region_name=REGION)

    def call(self, route, body=None, path=None):
        event = {"routeKey": route, "body": json.dumps(body) if body is not None else None,
                 "pathParameters": path}
        res = api.handler(event, None)
        return res["statusCode"], json.loads(res["body"]) if res.get("body") else None

    def test_full_flow(self):
        data = sample_image()
        status, body = self.call("POST /uploads", {"filename": "anh-lop.jpg", "contentType": "image/jpeg",
                                                   "size": len(data)})
        self.assertEqual(status, 201)
        upload = body["upload"]
        key = upload["fields"]["key"]
        self.assertTrue(key.startswith("uploads/") and key.endswith(".jpg"))
        self.assertEqual(upload["url"], f"https://{BUCKET}.s3.{REGION}.amazonaws.com/")
        self.assertIn("policy", upload["fields"])

        # Trình duyệt upload lên S3 -> S3 kích hoạt Lambda thumbnail
        self.s3.put_object(Bucket=BUCKET, Key=key, Body=data, ContentType="image/jpeg")
        status, images = self.call("GET /images")
        self.assertEqual(images["images"][0]["status"], "PENDING")
        thumbnail.handler(s3_event(key), None)

        status, images = self.call("GET /images")
        item = images["images"][0]
        self.assertEqual(item["status"], "DONE")
        self.assertEqual((item["originalWidth"], item["originalHeight"]), (1600, 1200))
        self.assertEqual((item["thumbWidth"], item["thumbHeight"]), (320, 240))
        self.assertLess(item["thumbBytes"], item["originalBytes"])
        self.assertIn("X-Amz-Signature", item["thumbUrl"])
        thumb = self.s3.get_object(Bucket=BUCKET, Key=item["thumbKey"])
        self.assertEqual(thumb["ContentType"], "image/jpeg")

        status, _ = self.call("DELETE /images/{id}", path={"id": item["id"]})
        self.assertEqual(status, 204)
        self.assertEqual(self.call("GET /images")[1]["images"], [])
        self.assertEqual(self.s3.list_objects_v2(Bucket=BUCKET).get("KeyCount"), 0)

    def test_transparent_png_and_portrait(self):
        data = sample_image("PNG", (900, 2000), "RGBA")
        thumb, orig, size = thumbnail.make_thumbnail(data)
        self.assertEqual(orig, (900, 2000))
        self.assertEqual(size, (144, 320))
        self.assertEqual(Image.open(io.BytesIO(thumb)).format, "JPEG")

    def test_small_image_is_not_enlarged(self):
        _, _, size = thumbnail.make_thumbnail(sample_image(size=(200, 100)))
        self.assertEqual(size, (200, 100))

    def test_corrupt_image_marks_failed(self):
        status, body = self.call("POST /uploads", {"filename": "hong.png", "contentType": "image/png", "size": 10})
        key = body["upload"]["fields"]["key"]
        self.s3.put_object(Bucket=BUCKET, Key=key, Body=b"not an image")
        thumbnail.handler(s3_event(key), None)
        item = self.call("GET /images")[1]["images"][0]
        self.assertEqual(item["status"], "FAILED")
        self.assertNotIn("thumbUrl", item)

    def test_ignores_objects_outside_uploads(self):
        self.assertEqual(thumbnail.handler(s3_event("thumbnails/abc.jpg"), None), {"processed": 1})
        self.assertEqual(self.s3.list_objects_v2(Bucket=BUCKET).get("KeyCount"), 0)

    def test_rejects_bad_uploads(self):
        bad = [
            "not json",
            {"filename": "a.gif", "contentType": "image/gif", "size": 10},
            {"filename": "a.jpg", "contentType": "image/jpeg", "size": 11 * 1024 * 1024},
            {"filename": "", "contentType": "image/jpeg", "size": 10},
            {"filename": "a.jpg", "contentType": "image/jpeg", "size": "10"},
        ]
        for body in bad:
            event = {"routeKey": "POST /uploads", "body": body if isinstance(body, str) else json.dumps(body)}
            self.assertEqual(api.handler(event, None)["statusCode"], 400, body)

    def test_unknown_route_and_missing_image(self):
        self.assertEqual(self.call("GET /nope")[0], 404)
        self.assertEqual(self.call("DELETE /images/{id}", path={"id": "missing"})[0], 404)


    def test_console_upload_without_api_record(self):
        # Ảnh upload thẳng qua S3 console (bước test 5.5): không có bản ghi PENDING từ API.
        key = "uploads/anh-console.jpg"
        self.s3.put_object(Bucket=BUCKET, Key=key, Body=sample_image(), ContentType="image/jpeg")
        thumbnail.handler(s3_event(key), None)
        status, body = self.call("GET /images")
        self.assertEqual(status, 200)
        item = body["images"][0]
        self.assertEqual((item["status"], item["originalKey"], item["filename"]), ("DONE", key, "anh-console.jpg"))
        self.assertIn("originalUrl", item)
        self.assertEqual(self.call("DELETE /images/{id}", path={"id": item["id"]})[0], 204)
        self.assertEqual(self.s3.list_objects_v2(Bucket=BUCKET).get("KeyCount"), 0)

    def test_record_without_keys_does_not_break_list(self):
        api.table().put_item(Item={"id": "orphan", "status": "PENDING", "createdAt": "2026-01-01T00:00:00+00:00"})
        status, body = self.call("GET /images")
        self.assertEqual(status, 200)
        self.assertEqual(self.call("DELETE /images/{id}", path={"id": "orphan"})[0], 204)

if __name__ == "__main__":
    unittest.main()
