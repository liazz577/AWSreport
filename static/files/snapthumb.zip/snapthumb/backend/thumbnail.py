"""SnapThumb - hàm Lambda tạo ảnh thu nhỏ.

Kích hoạt bởi sự kiện S3 ObjectCreated trên tiền tố uploads/.
Đọc ảnh gốc, tạo thumbnail JPEG (cạnh dài tối đa THUMB_MAX_SIZE px), ghi vào thumbnails/,
rồi cập nhật trạng thái và thông số vào DynamoDB.
"""
import io
import logging
import os
import urllib.parse
from datetime import datetime, timezone

import boto3
from PIL import Image, ImageOps

logger = logging.getLogger()
logger.setLevel(logging.INFO)

UPLOAD_PREFIX = "uploads/"
THUMB_PREFIX = "thumbnails/"
THUMB_MAX_SIZE = int(os.environ.get("THUMB_MAX_SIZE", "320"))
JPEG_QUALITY = 85

_s3 = None
_table = None


def s3():
    global _s3
    if _s3 is None:
        _s3 = boto3.client("s3")
    return _s3


def table():
    global _table
    if _table is None:
        _table = boto3.resource("dynamodb").Table(os.environ["TABLE_NAME"])
    return _table


def make_thumbnail(data, max_size=THUMB_MAX_SIZE):
    """Trả về (bytes JPEG của thumbnail, (rộng, cao) gốc, (rộng, cao) thumbnail)."""
    with Image.open(io.BytesIO(data)) as original:
        img = ImageOps.exif_transpose(original)  # xoay đúng chiều theo EXIF của ảnh điện thoại
        original_size = img.size
        if img.mode in ("RGBA", "LA") or (img.mode == "P" and "transparency" in img.info):
            # JPEG không có kênh trong suốt: đặt ảnh lên nền trắng
            rgba = img.convert("RGBA")
            img = Image.new("RGB", rgba.size, (255, 255, 255))
            img.paste(rgba, mask=rgba.split()[-1])
        elif img.mode not in ("RGB", "L"):
            img = img.convert("RGB")
        img.thumbnail((max_size, max_size), Image.LANCZOS)  # giữ nguyên tỉ lệ
        out = io.BytesIO()
        img.save(out, "JPEG", quality=JPEG_QUALITY, optimize=True, progressive=True)
        return out.getvalue(), original_size, img.size


def image_id_from_key(key):
    name = key[len(UPLOAD_PREFIX):]
    return name.rsplit(".", 1)[0]


def parse_time(value):
    return datetime.fromisoformat(value.replace("Z", "+00:00"))


def process_record(record):
    bucket = record["s3"]["bucket"]["name"]
    key = urllib.parse.unquote_plus(record["s3"]["object"]["key"])
    if not key.startswith(UPLOAD_PREFIX):
        logger.info("Skip %s (not under %s)", key, UPLOAD_PREFIX)
        return
    image_id = image_id_from_key(key)
    thumb_key = f"{THUMB_PREFIX}{image_id}.jpg"

    try:
        data = s3().get_object(Bucket=bucket, Key=key)["Body"].read()
        thumb, (ow, oh), (tw, th) = make_thumbnail(data)
        s3().put_object(Bucket=bucket, Key=thumb_key, Body=thumb, ContentType="image/jpeg")
        now = datetime.now(timezone.utc)
        processing_ms = int((now - parse_time(record["eventTime"])).total_seconds() * 1000)
        table().update_item(
            Key={"id": image_id},
            UpdateExpression=(
                "SET #s = :s, thumbKey = :tk, originalBytes = :ob, thumbBytes = :tb, "
                "originalWidth = :ow, originalHeight = :oh, thumbWidth = :tw, thumbHeight = :th, "
                "processedAt = :pa, processingMs = :pm, "
                # Ảnh upload thẳng qua S3 console không có bản ghi từ API: bổ sung các trường còn thiếu.
                "originalKey = if_not_exists(originalKey, :ok), filename = if_not_exists(filename, :fn), "
                "createdAt = if_not_exists(createdAt, :ca) REMOVE errorMessage"
            ),
            ExpressionAttributeNames={"#s": "status"},
            ExpressionAttributeValues={
                ":s": "DONE", ":tk": thumb_key, ":ob": len(data), ":tb": len(thumb),
                ":ow": ow, ":oh": oh, ":tw": tw, ":th": th,
                ":pa": now.isoformat(), ":pm": max(processing_ms, 0),
                ":ok": key, ":fn": key[len(UPLOAD_PREFIX):], ":ca": record["eventTime"],
            },
        )
        logger.info("Thumbnail %s: %dx%d -> %dx%d, %d -> %d bytes",
                    image_id, ow, oh, tw, th, len(data), len(thumb))
    except Exception as err:  # ảnh hỏng hoặc không đọc được: đánh dấu lỗi để giao diện hiển thị
        logger.exception("Failed to process %s", key)
        table().update_item(
            Key={"id": image_id},
            UpdateExpression=("SET #s = :s, errorMessage = :e, originalKey = if_not_exists(originalKey, :ok), "
                              "filename = if_not_exists(filename, :fn), createdAt = if_not_exists(createdAt, :ca)"),
            ExpressionAttributeNames={"#s": "status"},
            ExpressionAttributeValues={":s": "FAILED", ":e": str(err)[:300], ":ok": key,
                                       ":fn": key[len(UPLOAD_PREFIX):], ":ca": record["eventTime"]},
        )


def handler(event, context):
    for record in event.get("Records", []):
        process_record(record)
    return {"processed": len(event.get("Records", []))}
