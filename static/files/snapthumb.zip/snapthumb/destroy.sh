#!/usr/bin/env bash
# Xoá toàn bộ tài nguyên SnapThumb để không phát sinh chi phí.
set -euo pipefail

REGION="${AWS_REGION:-ap-southeast-1}"
STACK="${STACK_NAME:-snapthumb}"
export AWS_REGION="$REGION" AWS_DEFAULT_REGION="$REGION"

out() {
  aws cloudformation describe-stacks --stack-name "$STACK" \
    --query "Stacks[0].Outputs[?OutputKey=='$1'].OutputValue" --output text 2>/dev/null || true
}

read -r -p "Xoá stack '$STACK' ở $REGION cùng toàn bộ ảnh đã upload? Gõ 'yes' để tiếp tục: " CONFIRM
[ "$CONFIRM" = "yes" ] || { echo "Đã huỷ."; exit 0; }

for KEY in ImagesBucketName WebBucketName; do
  BUCKET="$(out "$KEY")"
  if [ -n "$BUCKET" ] && [ "$BUCKET" != "None" ]; then
    echo "Làm trống s3://$BUCKET"
    aws s3 rm "s3://$BUCKET" --recursive --quiet || true
  fi
done

echo "Xoá stack $STACK (mất vài phút)..."
aws cloudformation delete-stack --stack-name "$STACK"
aws cloudformation wait stack-delete-complete --stack-name "$STACK"
echo "Đã xoá xong. Kiểm tra lại Billing sau 1 ngày để chắc chắn không còn chi phí."
